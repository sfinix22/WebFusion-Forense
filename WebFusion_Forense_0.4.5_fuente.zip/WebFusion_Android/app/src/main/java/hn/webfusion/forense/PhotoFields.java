package hn.webfusion.forense;

/** Converts EXIF DMS values without guessing missing directions or time zones. */
public final class PhotoFields {
    private PhotoFields() {}
    public static Double coordinate(String dms, String ref, boolean latitude) {
        if(dms==null||ref==null)return null;
        ref=ref.trim();
        if(!(latitude?(ref.equals("N")||ref.equals("S")):(ref.equals("E")||ref.equals("W"))))return null;
        try {
            String[] parts=dms.split(",",-1);
            if(parts.length!=3)return null;
            double degrees=number(parts[0]),minutes=number(parts[1]),seconds=number(parts[2]);
            if(degrees<0||minutes<0||minutes>=60||seconds<0||seconds>=60)return null;
            double value=degrees+minutes/60+seconds/3600;
            if(!Double.isFinite(value)||value>(latitude?90:180))return null;
            return (ref.equals("S")||ref.equals("W"))?-value:value;
        }catch(RuntimeException e){return null;}
    }
    private static double number(String raw) {
        String[] p=raw.trim().split("/",-1);
        if(p.length>2)throw new IllegalArgumentException();
        double n=Double.parseDouble(p[0]);
        return p.length==2?n/Double.parseDouble(p[1]):n;
    }
}
