package hn.webfusion.forense;

import java.io.*;
import java.security.*;

public final class Digests {
    private Digests() {}
    public static String hash(InputStream in, long limit) throws IOException {
        return copyAndHash(in, new OutputStream() {
            public void write(int value) {}
            public void write(byte[] bytes, int offset, int length) {}
        }, limit);
    }
    public static String copyAndHash(InputStream in, OutputStream out, long limit) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[65536];
            long count = 0;
            int n;
            while ((n = in.read(buffer)) != -1) {
                count += n;
                if (count > limit) throw new IOException("Archivo mayor que el límite permitido");
                out.write(buffer, 0, n);
                md.update(buffer, 0, n);
            }
            StringBuilder result = new StringBuilder();
            for (byte b : md.digest()) result.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
            return result.toString();
        } catch (NoSuchAlgorithmException e) { throw new IOException(e); }
    }
}
