package hn.webfusion.forense;
import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Extracts bounded photo members into a fresh private working directory. */
public final class ZipPhotos {
    private ZipPhotos() {}
    public static final class Photo {
        public final File file; public final String member;
        Photo(File file,String member){this.file=file;this.member=member;}
    }
    public static List<Photo> extract(File archive,File dir,long limit,int countLimit)throws IOException {
        List<Photo> result=new ArrayList<>();long total=0;int seen=0;
        try(ZipFile zip=new ZipFile(archive)){
            Enumeration<? extends ZipEntry> entries=zip.entries();
            while(entries.hasMoreElements()){
                ZipEntry entry=entries.nextElement();if(++seen>1000)throw new IOException("ZIP con demasiadas entradas");
                String name=entry.getName().replace('\\','/');
                if(name.startsWith("/")||Arrays.asList(name.split("/")).contains(".."))throw new IOException("Ruta no válida dentro del ZIP");
                if(entry.isDirectory()||!name.toLowerCase(Locale.ROOT).matches(".*\\.(jpg|jpeg|png|webp)$"))continue;
                if(result.size()>=countLimit)throw new IOException("Demasiadas fotos dentro del ZIP");
                File sub=new File(dir,Integer.toString(result.size()));if(!sub.mkdirs())throw new IOException("No se pudo preparar la foto");
                File dest=new File(sub,name.substring(name.lastIndexOf('/')+1));
                CRC32 crc=new CRC32();long bytes=0;
                try(InputStream in=zip.getInputStream(entry);OutputStream out=new FileOutputStream(dest)){
                    byte[] buffer=new byte[8192];int n;
                    while((n=in.read(buffer))!=-1){total+=n;bytes+=n;if(total>limit)throw new IOException("Fotos del ZIP superan el límite de espacio");out.write(buffer,0,n);crc.update(buffer,0,n);}
                }
                if((entry.getSize()>=0&&bytes!=entry.getSize())||(entry.getCrc()>=0&&crc.getValue()!=entry.getCrc()))throw new IOException("ZIP dañado: no coincide la foto");
                result.add(new Photo(dest,entry.getName()));
            }
        }
        if(result.isEmpty())throw new IOException("El ZIP no contiene fotos compatibles");
        return result;
    }
    public static void cleanup(File dir){File[] children=dir.listFiles();if(children!=null)for(File c:children)cleanup(c);dir.delete();}
}
