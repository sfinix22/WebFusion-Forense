package hn.webfusion.forense;
import java.util.Locale;
public final class MapLocation {
    private MapLocation(){}
    public static boolean valid(double lat,double lon){return Double.isFinite(lat)&&Double.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180;}
    public static String coordinates(double lat,double lon){
        if(!valid(lat,lon))throw new IllegalArgumentException("Coordenadas inválidas");
        return String.format(Locale.ROOT,"%.7f,%.7f",lat,lon);
    }
    public static String geo(double lat,double lon){return "geo:0,0?q="+coordinates(lat,lon);}
    public static String web(double lat,double lon){return "https://www.google.com/maps/search/?api=1&query="+coordinates(lat,lon);}
}
