package hn.webfusion.forense;

import android.media.ExifInterface;
import java.io.*;
import java.time.Instant;
import java.util.Locale;
import org.json.*;

public final class PhotoMetadata {
    private PhotoMetadata() {}
    public static JSONObject read(File file) throws JSONException {
        JSONObject result=new JSONObject().put("readAt",Instant.now().toString());
        try {
            try(InputStream in=new FileInputStream(file)) {
                if(in.read()!=255||in.read()!=216)
                    return result.put("status","unsupported").put("note","Lectura EXIF disponible para JPG/JPEG en esta versión.");
            }
            ExifInterface exif=new ExifInterface(file.getPath());
            JSONObject tags=new JSONObject();
            for(String tag:new String[]{"Make","Model","DateTimeOriginal","DateTimeDigitized","DateTime","GPSLatitude","GPSLatitudeRef","GPSLongitude","GPSLongitudeRef"}) {
                String value=exif.getAttribute(tag);
                if(value!=null&&!value.trim().isEmpty())tags.put(tag,value);
            }
            result.put("tags",tags).put("status",tags.length()==0?"absent":"read");
            Double lat=PhotoFields.coordinate(tags.optString("GPSLatitude",null),tags.optString("GPSLatitudeRef",null),true);
            Double lon=PhotoFields.coordinate(tags.optString("GPSLongitude",null),tags.optString("GPSLongitudeRef",null),false);
            if(lat==null||lon==null){
                float[] coordinates=new float[2];
                if(exif.getLatLong(coordinates)&&Float.isFinite(coordinates[0])&&Float.isFinite(coordinates[1])
                    &&Math.abs(coordinates[0])<=90&&Math.abs(coordinates[1])<=180){
                    lat=(double)coordinates[0];lon=(double)coordinates[1];
                }
            }
            if(lat!=null&&lon!=null)result.put("latitude",lat).put("longitude",lon).put("gpsStatus","read");
            else result.put("gpsStatus",tags.has("GPSLatitude")||tags.has("GPSLongitude")?"invalid":"absent");
        }catch(IOException|RuntimeException e){result.put("status","error").put("note","No se pudieron leer los metadatos de esta copia.");}
        return result;
    }
    public static String describe(JSONObject metadata) {
        if(metadata==null)return "Metadatos pendientes: pulsa Leer metadatos.\n";
        if(metadata.optString("status").equals("error")||metadata.optString("status").equals("unsupported"))return metadata.optString("note")+"\n";
        JSONObject tags=metadata.optJSONObject("tags");if(tags==null)tags=new JSONObject();
        StringBuilder text=new StringBuilder("METADATOS DE LA FOTO\n");
        if(metadata.optString("status").equals("absent"))text.append("No hay etiquetas EXIF legibles en esta copia.\n");
        text.append("Fabricante: ").append(tags.optString("Make","No registrado")).append("\n");
        text.append("Modelo: ").append(tags.optString("Model","No registrado")).append("\n");
        text.append("Fecha original EXIF: ").append(tags.optString("DateTimeOriginal","No registrada")).append("\n");
        text.append("Fecha de digitalización EXIF: ").append(tags.optString("DateTimeDigitized","No registrada")).append("\n");
        text.append("Fecha de modificación EXIF: ").append(tags.optString("DateTime","No registrada")).append("\n");
        text.append("Fechas tal como están guardadas; no se presupone zona horaria ni se convierten a UTC.\n");
        if(metadata.has("latitude")&&metadata.has("longitude"))text.append(String.format(Locale.ROOT,"GPS: %.7f, %.7f\n",metadata.optDouble("latitude"),metadata.optDouble("longitude")));
        else text.append(metadata.optString("gpsStatus").equals("invalid")?"GPS: datos incompletos o no interpretables.\n":"GPS: no presente en la copia importada.\n");
        text.append("Los metadatos pueden haber sido modificados. No prueban por sí solos cuándo ni dónde se tomó la foto.\n");
        return text.toString();
    }
}
