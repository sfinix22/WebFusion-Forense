package hn.webfusion.forense;

import android.app.*;
import android.Manifest;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.graphics.*;
import android.hardware.usb.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import android.util.AtomicFile;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ArrayList<Button> buttons=new ArrayList<>();
    private LinearLayout list,root;
    private TextView status,heading;
    private EditText search;
    private File casesDir,caseDir;
    private JSONObject current;
    private boolean busy=false;
    private static final int IMPORT=10,EXPORT=11,MEDIA_LOCATION_PERMISSION=12,BACKUP=13,RESTORE=14,EXPORT_PDF=15;
    private static final long MAX_FILE=256L*1024*1024;
    private static final int TEXT_LIMIT=256*1024;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        casesDir=new File(getFilesDir(),"cases");casesDir.mkdirs();
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,24,24,24);
        root.setBackgroundColor(Color.rgb(10,23,37));scroll.addView(root);setContentView(scroll);
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(24,24+insets.getSystemWindowInsetTop(),24,24+insets.getSystemWindowInsetBottom());return insets;});
        text(root,"WEBFUSION · FORENSE",14);
        TextView version=text(root,"VERSIÓN 0.4.5"+(getPackageName().endsWith(".test")?" · PRUEBA":""),24);
        version.setTextColor(Color.rgb(112,224,197));
        heading=text(root,"Casos y archivos",28);
        text(root,"Novedades: duplicados por SHA-256, clasificación de archivos, EXIF/GPS y registro de custodia. También puedes importar un ZIP de fotos.",16);
        LinearLayout row=row(root);button(row,"Nuevo caso",this::newCase);button(row,"Abrir caso",this::openCase);
        button(root,"Renombrar caso",this::renameCase);
        row=row(root);button(row,"Importar archivos",this::chooseFiles);button(row,"USB detectados",this::usb);
        row=row(root);button(row,"Verificar copias",this::verifyCopies);button(row,"Exportar informe TXT",this::export);
        button(root,"Exportar informe PDF",this::exportPdf);
        button(root,"Leer metadatos de fotos",this::refreshMetadata);
        button(root,"Línea de tiempo de fotos",this::viewTimeline);
        row=row(root);button(row,"Ver duplicados",this::viewDuplicates);button(row,"Ver custodia",this::viewCustody);
        row=row(root);button(row,"Guardar respaldo",this::backup);button(row,"Restaurar caso",this::restore);
        status=text(root,"Crea o abre un caso para comenzar.",15);
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(Color.WHITE);search.setHintTextColor(Color.LTGRAY);search.setHint("Buscar texto o nombre de archivo");root.addView(search);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int b,int c){render();}public void afterTextChanged(Editable e){}});
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
        button(root,"Alcance y privacidad",()->show("Alcance", "Análisis local de archivos seleccionados. Sin conexión a internet ni root. Los casos quedan en el almacenamiento privado de la app, sin cifrado adicional propio. Desinstalar elimina los casos.\n\nCapturas de pantalla habilitadas: pueden contener datos del caso.\n\nLectura EXIF de JPG/JPEG. Al importar una foto se solicita permiso para acceder a su ubicación EXIF sin censura; no se consulta la ubicación actual del teléfono. Si no concedes el permiso, Android puede ocultar el GPS de las copias. El GPS también puede faltar en el propio archivo. Las fechas se muestran sin suponer zona horaria. Los metadatos son modificables y no demuestran por sí solos los hechos.\n\nNo desbloquea, descifra ni recupera eliminados. USB solo enumera dispositivos. La autorización declarada no se verifica automáticamente. Los originales no se modifican. No se afirma certificación ni validez pericial."));
        String last=getPreferences(0).getString("last","");
        if(last.matches("[a-f0-9-]{36}")) try{load(new File(casesDir,last));}catch(Exception e){status.setText("No se pudo reabrir el último caso. Usa Abrir caso.");}
    }
    private LinearLayout row(LinearLayout parent){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);parent.addView(r);return r;}
    private TextView text(LinearLayout parent,String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.rgb(225,236,247));t.setTextSize(size);t.setPadding(0,12,0,12);parent.addView(t);return t;}
    private Button button(LinearLayout parent,String label,Runnable action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);if(parent.getOrientation()==LinearLayout.HORIZONTAL)parent.addView(b,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));else parent.addView(b);buttons.add(b);b.setOnClickListener(v->{if(!busy)action.run();});return b;}
    private void lock(boolean v){busy=v;if(search!=null)search.setEnabled(!v);for(Button b:buttons)b.setEnabled(!v);}
    private EditText field(LinearLayout box,String hint){EditText e=new EditText(this);e.setHint(hint);box.addView(e);return e;}
    private void show(String title,String message){TextView t=new TextView(this);t.setText(message);t.setTextIsSelectable(true);t.setPadding(24,16,24,16);ScrollView s=new ScrollView(this);s.addView(t);new AlertDialog.Builder(this).setTitle(title).setView(s).setPositiveButton("Cerrar",null).show();}
    private void newCase(){
        LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(24,8,24,8);
        EditText title=field(form,"Nombre del caso"),client=field(form,"Cliente / solicitante"),scope=field(form,"Alcance autorizado"),auth=field(form,"Referencia del documento de autorización");
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Nuevo caso").setView(form).setPositiveButton("Crear",null).setNegativeButton("Cancelar",null).create();d.show();
        d.getButton(-1).setOnClickListener(v->{
            if(title.length()==0||client.length()==0||scope.length()==0||auth.length()==0){Toast.makeText(this,"Completa los cuatro campos",0).show();return;}
            try{
                File next=new File(casesDir,UUID.randomUUID().toString());if(!next.mkdirs())throw new IOException("No se pudo crear la carpeta");
                JSONObject data=new JSONObject().put("version",1).put("title",title.getText().toString()).put("client",client.getText().toString()).put("scope",scope.getText().toString()).put("authorizationReference",auth.getText().toString()).put("createdAt",Instant.now().toString()).put("files",new JSONArray());
                CustodyLog.append(data,"CASE_CREATED","", "Caso local creado; autorización declarada por el usuario.",data.getString("createdAt"));
                write(next,data);load(next);d.dismiss();
            }catch(Exception e){show("Error",e.toString());}
        });
    }
    private void write(File dir,JSONObject data)throws Exception{
        AtomicFile f=new AtomicFile(new File(dir,"case.json"));FileOutputStream out=null;
        try{out=f.startWrite();out.write(data.toString(2).getBytes(StandardCharsets.UTF_8));f.finishWrite(out);}catch(Exception e){if(out!=null)f.failWrite(out);throw e;}
    }
    private void load(File dir)throws Exception{
        JSONObject data=new JSONObject(new String(new AtomicFile(new File(dir,"case.json")).readFully(),StandardCharsets.UTF_8));
        current=data;caseDir=dir;getPreferences(0).edit().putString("last",dir.getName()).apply();search.setText("");render();
    }
    private String restoredAt(JSONObject data){
        JSONArray events=data.optJSONArray("custodyEvents");
        for(int i=events==null?-1:events.length()-1;i>=0;i--){JSONObject event=events.optJSONObject(i);if(event!=null&&"RESTORE".equals(event.optString("action")))return event.optString("occurredAt");}
        return "";
    }
    private String caseLabel(JSONObject data,File dir){
        String id=dir.getName();
        return data.optString("title")+(restoredAt(data).isEmpty()?"":" · RESTAURADO")+" · ID "+id.substring(0,Math.min(8,id.length()));
    }
    private void renameCase(){
        if(current==null){show("Caso requerido","Abre el caso que deseas renombrar.");return;}
        EditText name=new EditText(this);name.setSingleLine(true);name.setText(current.optString("title"));name.setSelectAllOnFocus(true);name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(120)});
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Renombrar caso").setView(name).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();dialog.show();
        dialog.getButton(-1).setOnClickListener(v->{
            String next=name.getText().toString().trim();
            if(next.isEmpty()){name.setError("Escribe un nombre");return;}
            if(next.equals(current.optString("title"))){dialog.dismiss();return;}
            try{
                JSONObject snapshot=new JSONObject(current.toString());String old=snapshot.optString("title");snapshot.put("title",next);
                CustodyLog.append(snapshot,"CASE_RENAMED","","Nombre anterior: "+old+"; nombre nuevo: "+next,null);
                write(caseDir,snapshot);current=snapshot;dialog.dismiss();render();status.setText("Nombre actualizado y cambio registrado en custodia.");
            }catch(Exception e){show("No se pudo renombrar",e.getMessage());}
        });
    }
    private void openCase(){
        File[] dirs=casesDir.listFiles(f->f.isDirectory()&&f.getName().matches("[a-f0-9-]{36}")&&new File(f,"case.json").exists());if(dirs==null||dirs.length==0){show("Casos","No hay casos guardados.");return;}
        Arrays.sort(dirs,Comparator.comparing(File::getName));String[] names=new String[dirs.length];
        for(int i=0;i<dirs.length;i++){try{JSONObject j=new JSONObject(new String(new AtomicFile(new File(dirs[i],"case.json")).readFully(),StandardCharsets.UTF_8));names[i]=caseLabel(j,dirs[i])+"\nCreado (UTC): "+j.optString("createdAt")+(restoredAt(j).isEmpty()?"":"\nRestaurado (UTC): "+restoredAt(j));}catch(Exception e){names[i]="Caso ilegible · "+dirs[i].getName();}}
        new AlertDialog.Builder(this).setTitle("Abrir caso").setItems(names,(d,i)->{try{load(dirs[i]);}catch(Exception e){show("Error",e.toString());}}).show();
    }
    private void chooseFiles(){
        if(current==null){show("Caso requerido","Crea o abre un caso.");return;}
        if(Build.VERSION.SDK_INT>=29&&checkSelfPermission(Manifest.permission.ACCESS_MEDIA_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            new AlertDialog.Builder(this).setTitle("GPS de las fotos")
                .setMessage("Android puede ocultar el GPS al copiar fotos. Permite acceder a la ubicación guardada en las fotos para analizar sus bytes originales. WebFusion no consulta tu ubicación actual. Para importar un ZIP de fotos puedes continuar sin este permiso.")
                .setPositiveButton("Solicitar permiso",(d,w)->requestPermissions(new String[]{Manifest.permission.ACCESS_MEDIA_LOCATION},MEDIA_LOCATION_PERMISSION))
                .setNegativeButton("Continuar sin permiso",(d,w)->openFilePicker()).show();
            return;
        }
        openFilePicker();
    }
    private void openFilePicker(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(i,IMPORT);}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(request,permissions,grants);
        if(request==MEDIA_LOCATION_PERMISSION){
            if(grants.length==0||grants[0]!=PackageManager.PERMISSION_GRANTED)show("GPS de las fotos","Permiso no concedido. Puedes importar archivos, pero Android podría ocultar la ubicación EXIF. Para probar el GPS, concede el permiso e importa la foto otra vez.");
            openFilePicker();
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null)return;
        if(request==BACKUP&&data.getData()!=null){saveBackup(data.getData());return;}
        if(request==RESTORE&&data.getData()!=null){restoreBackup(data.getData());return;}
        if(request==IMPORT){ArrayList<Uri> uris=new ArrayList<>();if(data.getClipData()!=null){for(int n=0;n<data.getClipData().getItemCount();n++)uris.add(data.getClipData().getItemAt(n).getUri());}else if(data.getData()!=null)uris.add(data.getData());importFiles(uris);}
        if(request==EXPORT_PDF&&data.getData()!=null){savePdf(data.getData());return;}
        if(request==EXPORT&&data.getData()!=null){String report=report();Uri uri=data.getData();lock(true);worker.execute(()->{String msg;try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("Destino no disponible");out.write(new byte[]{(byte)0xEF,(byte)0xBB,(byte)0xBF});out.write(report.getBytes(StandardCharsets.UTF_8));msg="Informe guardado. Contiene datos privados.";}catch(Exception e){msg="Error exportando: "+e.getMessage();}finish(msg);});}
    }
    private void finish(String msg){runOnUiThread(()->{if(isDestroyed())return;lock(false);render();status.setText(msg);});}
    private String selectedName(Uri uri){
        if("file".equals(uri.getScheme()))return uri.getLastPathSegment();
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst()&&!c.isNull(0))return c.getString(0);
        }
        return "archivo";
    }
    private void importFiles(ArrayList<Uri> uris){
        if(current==null||busy)return;lock(true);status.setText("Copiando y calculando SHA-256…");
        worker.execute(()->{int imported=0;StringBuilder errors=new StringBuilder();
            ArrayList<Uri> expanded=new ArrayList<>();ArrayList<File> temporary=new ArrayList<>();Map<String,String> origins=new HashMap<>();
            for(Uri selected:uris){try{
                String archiveName=selectedName(selected);
                if(!archiveName.toLowerCase(Locale.ROOT).endsWith(".zip")){expanded.add(selected);continue;}
                File dir=new File(getCacheDir(),"zip-"+UUID.randomUUID());if(!dir.mkdirs())throw new IOException("No se pudo preparar el ZIP");temporary.add(dir);
                File archive=new File(dir,"source.zip");String archiveHash;
                long budget=Math.min(MAX_FILE,Math.max(0,caseDir.getUsableSpace()-32L*1024*1024));
                try(InputStream in=getContentResolver().openInputStream(selected);OutputStream out=new FileOutputStream(archive)){
                    if(in==null)throw new IOException("ZIP no disponible");archiveHash=Digests.copyAndHash(in,out,budget);
                }
                budget=Math.min(MAX_FILE,Math.max(0,caseDir.getUsableSpace()-32L*1024*1024));
                List<ZipPhotos.Photo> photos=ZipPhotos.extract(archive,dir,budget,100-current.getJSONArray("files").length()-expanded.size());
                for(ZipPhotos.Photo photo:photos){Uri item=Uri.fromFile(photo.file);expanded.add(item);origins.put(item.toString(),"ZIP: "+archiveName+"; SHA-256 del ZIP: "+archiveHash+"; entrada: "+photo.member);}
            }catch(Exception ex){errors.append("\nZIP: ").append(ex.getMessage());}}
            for(Uri uri:expanded){File copy=null;try{
                if(current.getJSONArray("files").length()>=100)throw new IOException("Máximo 100 archivos por caso");
                String name=selectedName(uri);
                if(name==null)name="archivo";String id=UUID.randomUUID().toString();copy=new File(caseDir,id+".bin");String hash;
                Uri source=uri;
                if("content".equals(uri.getScheme())&&Build.VERSION.SDK_INT>=29&&checkSelfPermission(Manifest.permission.ACCESS_MEDIA_LOCATION)==PackageManager.PERMISSION_GRANTED){
                    String mime=getContentResolver().getType(uri);
                    if((mime!=null&&mime.startsWith("image/"))||name.toLowerCase(Locale.ROOT).matches(".*\\.(jpg|jpeg|png|webp)$")){
                        Uri media="media".equals(uri.getAuthority())?uri:MediaStore.getMediaUri(this,uri);
                        if(media!=null)source=MediaStore.setRequireOriginal(media);
                    }
                }
                try(InputStream in=getContentResolver().openInputStream(source);OutputStream out=new FileOutputStream(copy)){if(in==null)throw new IOException("No se pudo abrir el archivo");hash=Digests.copyAndHash(in,out,Math.min(MAX_FILE,Math.max(0,caseDir.getUsableSpace()-32L*1024*1024)));}
                JSONObject e=new JSONObject().put("name",name).put("localFile",copy.getName()).put("bytes",copy.length()).put("sha256",hash).put("importedAt",Instant.now().toString()).put("classification",EvidenceFiles.classify(name));
                String origin=origins.get(uri.toString());
                if(origin!=null)e.put("sourceNote",origin);
                analyze(copy,e);
                JSONArray items=current.getJSONArray("files");int eventCount=current.optJSONArray("custodyEvents")==null?0:current.getJSONArray("custodyEvents").length();
                ArrayList<String> previousHashes=new ArrayList<>();for(int n=0;n<items.length();n++){JSONObject prior=items.optJSONObject(n);previousHashes.add(prior==null?"":prior.optString("sha256"));}
                int duplicateIndex=EvidenceFiles.findDuplicateIndex(previousHashes,hash);
                JSONObject duplicate=duplicateIndex<0?null:items.optJSONObject(duplicateIndex);
                if(duplicate!=null)e.put("duplicate",true).put("duplicateOf",duplicate.optString("name")).put("duplicateOfImportedAt",duplicate.optString("importedAt"));
                items.put(e);
                try{
                    CustodyLog.append(current,"IMPORT",name,"bytes="+copy.length()+"; sha256="+hash+"; classification="+e.optString("classification")+(origin==null?"":"; "+origin)+(duplicate==null?"":"; duplicateOf="+duplicate.optString("name")),e.getString("importedAt"));
                    write(caseDir,current);
                }catch(Exception ex){items.remove(items.length()-1);trimCustodyEvents(current,eventCount);throw ex;}imported++;
            }catch(Exception e){if(copy!=null)copy.delete();errors.append("\n").append(e.getMessage());}}
            for(File dir:temporary)ZipPhotos.cleanup(dir);
            JSONArray all=current.optJSONArray("files");int totalFiles=all==null?0:all.length(),duplicates=0;
            for(int i=0;all!=null&&i<all.length();i++){JSONObject e=all.optJSONObject(i);if(e!=null&&e.optBoolean("duplicate"))duplicates++;}
            String message=(imported==1?"Se importó 1 archivo.":"Se importaron "+imported+" archivos.")+" Total del caso: "+totalFiles+". Duplicados: "+duplicates+".";
            finish(message+errors);
        });
    }
    private void analyze(File f,JSONObject entry)throws Exception{
        String name=entry.optString("name").toLowerCase(Locale.ROOT);
        if(name.matches(".*\\.(jpg|jpeg|png|webp)$")){
            BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeFile(f.getPath(),o);
            if(o.outWidth>0)entry.put("width",o.outWidth).put("height",o.outHeight).put("kind","image");else entry.put("analysisNote","Imagen no reconocida");
            if(o.outWidth>0)entry.put("photoMetadata",PhotoMetadata.read(f));
            return;
        }
        if(!name.matches(".*\\.(txt|csv|json|html|htm)$")){entry.put("analysisNote","Inventariado y huella calculada; este formato no tiene decodificador en v0.2. Extrae los ZIP antes de importar sus archivos.");return;}
        if(f.length()>TEXT_LIMIT){entry.put("analysisNote","Texto mayor de 256 KB: conservado y con huella, sin indexación para limitar memoria.");return;}
        String content=new String(Files.readAllBytes(f.toPath()),StandardCharsets.UTF_8);
        if(name.endsWith(".html")||name.endsWith(".htm"))content=Html.fromHtml(content,Html.FROM_HTML_MODE_LEGACY).toString();
        if(name.endsWith(".json"))try{
            Object parsed=new JSONTokener(content).nextValue();
            if(parsed instanceof JSONObject&&((JSONObject)parsed).optJSONArray("messages")!=null){
                JSONArray messages=((JSONObject)parsed).getJSONArray("messages");StringBuilder s=new StringBuilder();
                for(int i=0;i<messages.length();i++){JSONObject m=messages.optJSONObject(i);if(m==null)continue;s.append(m.optString("sender_name","Sin remitente")).append(" | ");try{s.append(Instant.ofEpochMilli(m.getLong("timestamp_ms")));}catch(Exception ex){s.append("Sin fecha interpretable");}s.append("\n").append(m.optString("content","[Sin texto; revisar campos originales]")).append("\n\n");}content=s.toString();entry.put("messageCount",messages.length());
            }
        }catch(Exception e){entry.put("analysisNote","JSON no interpretable; mostrado como texto original.");}
        entry.put("kind","text").put("text",content);
    }
    private void trimCustodyEvents(JSONObject data,int length){JSONArray events=data.optJSONArray("custodyEvents");if(events!=null)while(events.length()>length)events.remove(events.length()-1);}
    private void render(){
        if(list==null)return;list.removeAllViews();if(current==null)return;
        heading.setText(caseLabel(current,caseDir));JSONArray entries=current.optJSONArray("files");if(entries==null)return;
        String query=search.getText().toString().toLowerCase(Locale.ROOT);int shown=0;
        for(int i=0;i<entries.length();i++){JSONObject e=entries.optJSONObject(i);if(e==null)continue;if(!(e.optString("name")+" "+e.optString("text")).toLowerCase(Locale.ROOT).contains(query))continue;shown++;
            String itemLabel=e.optString("name")+"\n"+e.optLong("bytes")+" bytes · "+e.optString("classification",e.optString("kind","archivo"))+(e.optBoolean("duplicate")?" · DUPLICADO":"");
            TextView title=text(list,itemLabel,18);title.setBackgroundColor(Color.rgb(24,46,66));title.setOnClickListener(v->{if(!busy)inspect(e);});
        }
        int duplicates=0;for(int i=0;i<entries.length();i++){JSONObject e=entries.optJSONObject(i);if(e!=null&&e.optBoolean("duplicate"))duplicates++;}
        JSONArray events=current.optJSONArray("custodyEvents");
        status.setText(shown+" de "+entries.length()+" archivos · "+duplicates+" duplicados · "+(events==null?0:events.length())+" eventos de custodia");
    }
    private void viewDuplicates(){
        if(current==null){show("Caso requerido","Crea o abre un caso y después importa archivos.");return;}
        JSONArray items=current.optJSONArray("files");StringBuilder out=new StringBuilder();int count=0;
        for(int i=0;items!=null&&i<items.length();i++){JSONObject e=items.optJSONObject(i);if(e!=null&&e.optBoolean("duplicate")){count++;out.append("• ").append(e.optString("name")).append("\nCoincide con: ").append(e.optString("duplicateOf")).append("\nSHA-256: ").append(e.optString("sha256")).append("\n\n");}}
        show("Duplicados: "+count,count==0?"No hay duplicados detectados. Para probarlo, importa dos veces el mismo archivo al caso: el segundo debe aparecer como DUPLICADO.":out.toString());
    }
    private void viewCustody(){
        if(current==null){show("Caso requerido","Crea o abre un caso para ver su registro.");return;}
        JSONArray events=current.optJSONArray("custodyEvents");StringBuilder out=new StringBuilder();
        out.append("Estado de la cadena: ").append(CustodyLog.verify(current)?"coincide":"NO COINCIDE").append("\n");
        out.append("Eventos: ").append(events==null?0:events.length()).append("\n\n");
        for(int i=0;events!=null&&i<events.length();i++){JSONObject e=events.optJSONObject(i);if(e!=null)out.append(e.optInt("sequence")).append(". ").append(e.optString("action")).append(" · ").append(e.optString("occurredAt")).append("\n").append(e.optString("fileName")).append("\n").append(e.optString("details")).append("\n\n");}
        if(events==null||events.length()==0)out.append("Los casos antiguos comienzan su registro al importar o verificar archivos.");
        out.append("\nRegistro local; no equivale a un sello de tiempo externo ni a una firma digital.");
        show("Registro de custodia",out.toString());
    }
    private String originalPhotoDate(JSONObject entry){
        JSONObject metadata=entry.optJSONObject("photoMetadata");
        JSONObject tags=metadata==null?null:metadata.optJSONObject("tags");
        return tags==null?"":tags.optString("DateTimeOriginal");
    }
    private void viewTimeline(){
        if(current==null){show("Caso requerido","Abre un caso para ver sus fotos.");return;}
        ArrayList<JSONObject> photos=new ArrayList<>();JSONArray files=current.optJSONArray("files");
        for(int i=0;files!=null&&i<files.length();i++){
            JSONObject entry=files.optJSONObject(i);
            if(entry!=null&&"image".equals(entry.optString("kind")))photos.add(entry);
        }
        if(photos.isEmpty()){show("Línea de tiempo","Este caso no contiene fotos importadas.");return;}
        // List.sort is stable: equal or missing dates preserve import order.
        photos.sort((a,b)->PhotoTimeline.compare(originalPhotoDate(a),originalPhotoDate(b)));
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,12,24,12);
        TextView intro=new TextView(this);intro.setText("Orden por fecha original EXIF, de más antigua a más reciente. Sin conversión de zona horaria. Los metadatos no prueban por sí solos el orden real de los hechos.\nSe muestran todas las importaciones, incluidos duplicados.\n");box.addView(intro);
        boolean missingHeader=false,datedHeader=false;
        for(JSONObject entry:photos){
            String date=originalPhotoDate(entry);boolean valid=PhotoTimeline.parse(date)!=null;
            if((valid&&!datedHeader)||(!valid&&!missingHeader)){
                TextView group=new TextView(this);group.setText(valid?"CON FECHA ORIGINAL EXIF":"SIN FECHA ORIGINAL EXIF VÁLIDA");group.setTypeface(null,android.graphics.Typeface.BOLD);group.setPadding(0,24,0,12);box.addView(group);
                if(valid)datedHeader=true;else missingHeader=true;
            }
            JSONObject metadata=entry.optJSONObject("photoMetadata");
            double lat=metadata==null?Double.NaN:metadata.optDouble("latitude",Double.NaN),lon=metadata==null?Double.NaN:metadata.optDouble("longitude",Double.NaN);
            boolean gps=MapLocation.valid(lat,lon);
            TextView info=new TextView(this);info.setPadding(0,20,0,8);
            info.setText(PhotoTimeline.display(date)+"\n"+entry.optString("name")+(entry.optBoolean("duplicate")?" · DUPLICADO":"")+
                "\nGPS: "+(gps?MapLocation.coordinates(lat,lon):"No disponible en la lectura guardada")+
                (metadata==null?"\nMetadatos pendientes: pulsa Leer metadatos de fotos.":(!valid&&!date.isEmpty()?"\nValor EXIF no interpretable: "+date:"")));
            box.addView(info);
            LinearLayout actions=row(box);
            Button details=new Button(this);details.setText("Ver foto y detalles");details.setAllCaps(false);actions.addView(details,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));details.setOnClickListener(v->inspect(entry));
            if(gps){Button map=new Button(this);map.setText("Abrir mapa");map.setAllCaps(false);actions.addView(map,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));map.setOnClickListener(v->openPhotoMap(lat,lon));}
        }
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        new AlertDialog.Builder(this).setTitle("Línea de tiempo · "+photos.size()+" fotos").setView(scroll).setPositiveButton("Cerrar",null).show();
    }
    private JSONObject findPhoto(JSONObject data,String local){
        JSONArray files=data.optJSONArray("files");
        for(int i=0;files!=null&&i<files.length();i++){
            JSONObject entry=files.optJSONObject(i);
            if(entry!=null&&local.equals(entry.optString("localFile"))&&"image".equals(entry.optString("kind")))return entry;
        }
        return null;
    }
    private void editPhotoNote(String local,TextView display){
        if(current==null||busy)return;
        final File directory=caseDir;JSONObject entry=findPhoto(current,local);if(entry==null)return;
        EditText input=new EditText(this);input.setMinLines(3);input.setMaxLines(8);
        input.setGravity(Gravity.TOP);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2000)});input.setText(entry.optString("userNote"));
        LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(24,12,24,12);
        TextView help=new TextView(this);help.setText("Observación del analista para esta importación (máximo 2000 caracteres). Vacía el texto para quitar la nota actual; el historial conserva los cambios anteriores.");form.addView(help);form.addView(input);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Nota de análisis").setView(form).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();dialog.show();
        dialog.getButton(-1).setOnClickListener(v->{
            if(busy||current==null||!directory.equals(caseDir)){show("Caso cambiado","Vuelve a abrir la foto en el caso actual.");return;}
            String next=input.getText().toString();
            try{
                JSONObject snapshot=new JSONObject(current.toString()),photo=findPhoto(snapshot,local);
                if(photo==null)throw new IOException("La foto no está en este caso");
                String old=photo.optString("userNote");if(old.equals(next)){dialog.dismiss();return;}
                String now=Instant.now().toString();photo.put("userNote",next).put("userNoteUpdatedAt",now);
                String detail=new JSONObject().put("localFile",local).put("sha256",photo.optString("sha256")).put("previousNote",old).put("newNote",next).toString();
                CustodyLog.append(snapshot,"PHOTO_NOTE_UPDATED",photo.optString("name"),detail,now);
                write(directory,snapshot);current=snapshot;display.setText(photoNoteText(photo));dialog.dismiss();render();status.setText("Nota guardada y cambio registrado en custodia.");
            }catch(Exception error){show("No se pudo guardar la nota",error.getMessage());}
        });
    }
    private String photoNoteText(JSONObject entry){
        String note=entry.optString("userNote");
        return "NOTA DEL ANALISTA\n"+(note.isEmpty()?"Sin nota actual.":note)+(entry.has("userNoteUpdatedAt")?"\nActualizada UTC: "+entry.optString("userNoteUpdatedAt"):"");
    }
    private void inspect(JSONObject e){
        if(current!=null){JSONObject latest=findPhoto(current,e.optString("localFile"));if(latest!=null)e=latest;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(20,12,20,12);
        String body="Clasificación: "+e.optString("classification","Sin clasificar")+"\nSHA-256: "+e.optString("sha256")+"\nImportado (UTC): "+e.optString("importedAt")+"\n"+e.optString("analysisNote")+"\n\n";
        if(e.has("sourceNote"))body+=e.optString("sourceNote")+"\n\n";
        if(e.optBoolean("duplicate"))body+="Contenido duplicado de: "+e.optString("duplicateOf")+" (coincidencia SHA-256)\n\n";
        if(e.has("width"))body+=e.optInt("width")+" × "+e.optInt("height")+" píxeles\n";
        if(e.optString("kind").equals("image"))body+=PhotoMetadata.describe(e.optJSONObject("photoMetadata"))+"\n";
        if(e.has("lastVerification"))body+="Verificación: "+e.optJSONObject("lastVerification").toString()+"\n\n";
        String content=e.optString("text");body+=content.substring(0,Math.min(content.length(),30000));if(content.length()>30000)body+="\n[Vista limitada. El informe incluye todo el texto indexado.]";
        JSONObject metadata=e.optJSONObject("photoMetadata");
        double latitude=metadata==null?Double.NaN:metadata.optDouble("latitude",Double.NaN);
        double longitude=metadata==null?Double.NaN:metadata.optDouble("longitude",Double.NaN);
        if(MapLocation.valid(latitude,longitude)){
            Button map=new Button(this);map.setText("Abrir ubicación en el mapa");map.setAllCaps(false);box.addView(map);
            map.setOnClickListener(v->openPhotoMap(latitude,longitude));
        }
        if("image".equals(e.optString("kind"))){
            TextView note=text(box,photoNoteText(e),15);note.setTextIsSelectable(true);
            Button edit=new Button(this);edit.setText("Editar nota de análisis");edit.setAllCaps(false);box.addView(edit);
            final String local=e.optString("localFile");edit.setOnClickListener(v->editPhotoNote(local,note));
        }
        TextView t=text(box,body,15);t.setTextIsSelectable(true);
        if(e.optString("kind").equals("image")){BitmapFactory.Options o=new BitmapFactory.Options();int max=Math.max(e.optInt("width"),e.optInt("height"));o.inSampleSize=1;while(max/o.inSampleSize>1000)o.inSampleSize*=2;Bitmap bitmap=BitmapFactory.decodeFile(new File(caseDir,e.optString("localFile")).getPath(),o);if(bitmap!=null){ImageView image=new ImageView(this);image.setAdjustViewBounds(true);image.setImageBitmap(bitmap);box.addView(image);}}
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        new AlertDialog.Builder(this).setTitle(e.optString("name")).setView(scroll).setPositiveButton("Cerrar",null).show();
    }
    private void openPhotoMap(double latitude,double longitude){
        try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(MapLocation.geo(latitude,longitude))));}
        catch(ActivityNotFoundException ex){
            try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(MapLocation.web(latitude,longitude))));}
            catch(ActivityNotFoundException missing){show("Mapa no disponible","No hay una aplicación de mapas ni navegador disponible. Coordenadas: "+MapLocation.coordinates(latitude,longitude));}
        }
    }
    private void refreshMetadata(){
        if(current==null){show("Caso requerido","Crea o abre un caso.");return;}
        final JSONObject snapshot;
        try{snapshot=new JSONObject(current.toString());}catch(Exception e){show("Error",e.toString());return;}
        final File dir=caseDir;lock(true);status.setText("Leyendo metadatos de las copias…");
        worker.execute(()->{
            try{
                int count=0;JSONArray entries=snapshot.getJSONArray("files");
                for(int i=0;i<entries.length();i++){
                    JSONObject entry=entries.getJSONObject(i);
                    if(!entry.optString("kind").equals("image"))continue;
                    String local=entry.getString("localFile");
                    if(!local.matches("[a-f0-9-]{36}[.]bin"))throw new IOException("Referencia inválida");
                    entry.put("photoMetadata",PhotoMetadata.read(new File(dir,local)));count++;
                }
                CustodyLog.append(snapshot,"METADATA_READ","", "Metadatos consultados en "+count+" copias de imagen.",null);
                write(dir,snapshot);String message="Lectura terminada: "+count+" fotos.";
                StringBuilder summary=new StringBuilder();int displayed=0;
                for(int i=0;i<entries.length();i++){
                    JSONObject entry=entries.optJSONObject(i);
                    if(entry==null||!entry.optString("kind").equals("image"))continue;
                    if(displayed>=10)break;
                    summary.append(entry.optString("name")).append("\n").append(PhotoMetadata.describe(entry.optJSONObject("photoMetadata"))).append("\n");displayed++;
                }
                if(count>displayed)summary.append("Se muestran ").append(displayed).append(" de ").append(count).append(" fotos. Toca cualquier foto de la lista para revisar la suya.\n");
                String result=summary.length()==0?"No hay fotos en este caso.":summary.toString();
                runOnUiThread(()->{if(isDestroyed())return;current=snapshot;lock(false);render();status.setText(message);show("Metadatos de fotos",result);});
            }catch(Exception e){finish("No se pudo guardar la lectura: "+e.getMessage());}
        });
    }
    private void verifyCopies(){
        if(current==null){show("Caso requerido","Crea o abre un caso.");return;}
        lock(true);status.setText("Verificando copias con SHA-256…");
        final File dir=caseDir;
        final JSONObject snapshot;
        try{snapshot=new JSONObject(current.toString());}catch(Exception e){lock(false);show("Error",e.toString());return;}
        worker.execute(()->{
            int ok=0,changed=0,unreadable=0;
            try{
                JSONArray entries=snapshot.getJSONArray("files");
                for(int i=0;i<entries.length();i++){
                    JSONObject entry=entries.getJSONObject(i);
                    JSONObject check=new JSONObject().put("checkedAt",Instant.now().toString());
                    try{
                        String local=entry.getString("localFile");
                        if(!local.matches("[a-f0-9-]{36}[.]bin"))throw new IOException("Referencia inválida");
                        File file=new File(dir,local);
                        String actual;
                        try(InputStream in=new FileInputStream(file)){actual=Digests.hash(in,MAX_FILE);}
                        boolean match=actual.equals(entry.getString("sha256"))&&file.length()==entry.getLong("bytes");
                        check.put("status",match?"coincide":"diferente").put("actualSha256",actual).put("actualBytes",file.length());
                        if(match)ok++;else changed++;
                    }catch(Exception e){check.put("status","no_verificable").put("detail",String.valueOf(e.getMessage()));unreadable++;}
                    entry.put("lastVerification",check);
                    CustodyLog.append(snapshot,"VERIFY",entry.optString("name"),"status="+check.optString("status")+"; sha256="+check.optString("actualSha256", "no disponible"),check.getString("checkedAt"));
                }
                write(dir,snapshot);
                String result="Verificación: "+ok+" coinciden, "+changed+" diferentes, "+unreadable+" no verificables.";
                runOnUiThread(()->{if(isDestroyed())return;current=snapshot;lock(false);render();status.setText(result);});
            }catch(Exception e){finish("No se pudo guardar la verificación: "+e.getMessage());}
        });
    }
    private void usb(){
        UsbManager manager=(UsbManager)getSystemService(USB_SERVICE);StringBuilder s=new StringBuilder();
        if(manager!=null)for(UsbDevice d:manager.getDeviceList().values())s.append("Dispositivo: ").append(d.getDeviceName()).append("\nFabricante USB (VID): ").append(d.getVendorId()).append("\nProducto (PID): ").append(d.getProductId()).append("\nInterfaces: ").append(d.getInterfaceCount()).append("\n\n");
        if(s.length()==0)s.append("No se detectaron dispositivos USB.\n");
        s.append("\nEsta lista no indica acceso al almacenamiento ni extracción de datos. No se envían comandos al equipo.");show("USB detectados",s.toString());
    }
    private String report(){
        StringBuilder s=new StringBuilder("WEBFUSION FORENSE · INFORME DE ANÁLISIS LOCAL v0.4.5\n");s.append("Generado UTC: ").append(Instant.now()).append("\n");
        for(String key:new String[]{"title","client","scope","authorizationReference","createdAt"})s.append(key).append(": ").append(current.optString(key)).append("\n");
        JSONArray a=current.optJSONArray("files");int duplicateCount=0;for(int i=0;a!=null&&i<a.length();i++)if(a.optJSONObject(i)!=null&&a.optJSONObject(i).optBoolean("duplicate"))duplicateCount++;
        JSONArray events=current.optJSONArray("custodyEvents");
        s.append("ID local del caso: ").append(caseDir.getName()).append("\n");
        if(!restoredAt(current).isEmpty())s.append("Caso restaurado (UTC): ").append(restoredAt(current)).append("\n");
        s.append("\nRESUMEN\nArchivos registrados: ").append(a==null?0:a.length()).append("\nDuplicados por coincidencia SHA-256: ").append(duplicateCount).append("\nEventos de custodia locales: ").append(events==null?0:events.length()).append("\nCadena de eventos: ").append(CustodyLog.verify(current)?"íntegra en esta comprobación":"NO COINCIDE; revisar el registro").append("\n");
        s.append("\nALCANCE Y LIMITACIONES\nArchivos seleccionados; no es una imagen forense completa. No desbloquea dispositivos ni recupera archivos eliminados. Las fechas de importación no son fechas de los hechos. La referencia de autorización es declarada, no verificada por la app. El registro encadenado se guarda dentro del mismo almacenamiento local y no constituye una firma, sello de tiempo externo ni certificación pericial.\n");
        s.append("\nARCHIVOS\n");
        for(int i=0;a!=null&&i<a.length();i++){JSONObject e=a.optJSONObject(i);if(e!=null){s.append("\n================\nNombre: ").append(e.optString("name")).append("\nClasificación: ").append(e.optString("classification","Sin clasificar")).append("\nTamaño: ").append(e.optLong("bytes")).append(" bytes\nSHA-256: ").append(e.optString("sha256")).append("\nImportado UTC: ").append(e.optString("importedAt")).append("\n");if(e.has("userNoteUpdatedAt"))s.append("\n").append(photoNoteText(e)).append("\n");if(e.has("sourceNote"))s.append("Origen: ").append(e.optString("sourceNote")).append("\n");if(e.optBoolean("duplicate"))s.append("Duplicado de: ").append(e.optString("duplicateOf")).append(" (hash coincidente)\n");if(e.has("lastVerification"))s.append("Última verificación: ").append(e.optJSONObject("lastVerification")).append("\n");if(e.optString("kind").equals("image"))s.append(PhotoMetadata.describe(e.optJSONObject("photoMetadata")));else if(e.has("text"))s.append("Texto legible:\n").append(e.optString("text")).append("\n");else if(e.has("analysisNote"))s.append(e.optString("analysisNote")).append("\n");}}
        s.append("\nREGISTRO DE CUSTODIA LOCAL\n");for(int i=0;events!=null&&i<events.length();i++)s.append(events.optJSONObject(i)).append("\n");
        return s.toString();
    }
    private void backup(){
        if(current==null){show("Caso requerido","Abre el caso que deseas respaldar.");return;}
        new AlertDialog.Builder(this).setTitle("Guardar respaldo").setMessage("Incluye archivos, metadatos y custodia. ZIP sin cifrado; máximo 1 GB.")
            .setPositiveButton("Elegir destino",(d,w)->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,"WebFusion_caso_"+caseDir.getName()+".zip");startActivityForResult(i,BACKUP);}).setNegativeButton("Cancelar",null).show();
    }
    private void restore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");startActivityForResult(i,RESTORE);}
    private void saveBackup(Uri uri){
        if(current==null)return;final File dir=caseDir;lock(true);status.setText("Verificando y guardando respaldo…");
        worker.execute(()->{File temp=new File(getCacheDir(),"backup-"+UUID.randomUUID()+".zip");
            try{
                long required=16L*1024*1024;File[] files=dir.listFiles();if(files!=null)for(File f:files)required+=f.length();
                if(getCacheDir().getUsableSpace()<required+32L*1024*1024)throw new IOException("Espacio insuficiente");
                try(OutputStream out=new FileOutputStream(temp)){CaseBackup.create(dir,out);}
                try(InputStream in=new FileInputStream(temp);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
                    if(out==null)throw new IOException("Destino no disponible");Digests.copyAndHash(in,out,CaseBackup.LIMIT+32L*1024*1024);
                }
                finish("Respaldo completo guardado. Archivos y custodia verificados.");
            }catch(Exception e){finish("No se completó el respaldo: "+e.getMessage()+". No uses el archivo incompleto del destino.");}
            finally{temp.delete();}
        });
    }
    private void restoreBackup(Uri uri){
        lock(true);status.setText("Restaurando y comprobando SHA-256…");
        worker.execute(()->{File stage=new File(casesDir,"restore-"+UUID.randomUUID());File destination=new File(casesDir,UUID.randomUUID().toString());
            try{
                if(!stage.mkdirs())throw new IOException("No se pudo preparar la restauración");
                try(InputStream in=getContentResolver().openInputStream(uri)){
                    if(in==null)throw new IOException("Respaldo no disponible");
                    CaseBackup.extract(in,stage,Math.max(0,casesDir.getUsableSpace()-32L*1024*1024));
                }
                JSONObject restored=CaseBackup.validate(stage);
                CustodyLog.append(restored,"RESTORE","","Respaldo restaurado como caso independiente; archivos y cadena previa comprobados.",null);
                write(stage,restored);
                if(!stage.renameTo(destination))throw new IOException("No se pudo guardar el caso restaurado");
                runOnUiThread(()->{if(isDestroyed())return;lock(false);try{load(destination);status.setText("Caso restaurado y verificado. Se creó una copia independiente.");}catch(Exception e){show("Error",e.toString());}});
            }catch(Exception e){finish("No se restauró el caso: "+e.getMessage());}
            finally{ZipPhotos.cleanup(stage);}
        });
    }
    private void exportPdf(){
        if(current==null){show("Caso requerido","Crea o abre un caso.");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,"WebFusion_informe.pdf");startActivityForResult(i,EXPORT_PDF);
    }
    private void savePdf(Uri uri){
        if(current==null)return;
        final File directory=caseDir;final JSONObject snapshot;
        try{snapshot=new JSONObject(current.toString());}catch(Exception e){show("Error",e.toString());return;}
        lock(true);status.setText("Generando informe PDF con fotos…");
        worker.execute(()->{
            try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
                if(out==null)throw new IOException("Destino no disponible");
                PdfReport.write(out,snapshot,directory);finish("Informe PDF guardado.");
            }catch(Exception e){finish("No se completó el PDF: "+e.getMessage()+". No uses el archivo incompleto.");}
        });
    }
    private void export(){if(current==null){show("Caso requerido","Crea o abre un caso.");return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"WebFusion_informe.txt");startActivityForResult(i,EXPORT);}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdown();}
}
