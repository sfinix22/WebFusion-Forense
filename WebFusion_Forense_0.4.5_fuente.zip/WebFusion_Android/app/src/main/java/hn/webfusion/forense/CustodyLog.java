package hn.webfusion.forense;

import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/** Local, hash-linked audit notes. This is tamper-evident only while the case file is trusted. */
public final class CustodyLog {
    private CustodyLog() {}
    private static final String ZERO_HASH = "0000000000000000000000000000000000000000000000000000000000000000";

    public static final class Event {
        public final int sequence;
        public final String occurredAt, action, fileName, details, previousHash, eventHash;
        public Event(int sequence, String occurredAt, String action, String fileName, String details, String previousHash, String eventHash) {
            this.sequence=sequence;this.occurredAt=occurredAt;this.action=action;this.fileName=fileName;
            this.details=details;this.previousHash=previousHash;this.eventHash=eventHash;
        }
    }

    public static Event appendEvent(List<Event> events, String action, String fileName, String details, String at) throws Exception {
        if(!verifyEvents(events))throw new IllegalStateException("El registro de custodia no coincide; no se añadieron eventos.");
        String previous=events.isEmpty()?ZERO_HASH:events.get(events.size()-1).eventHash;
        Event unsigned=new Event(events.size()+1,at==null?Instant.now().toString():at,action,
                fileName==null?"":fileName,details==null?"":details,previous,"");
        Event complete=new Event(unsigned.sequence,unsigned.occurredAt,unsigned.action,unsigned.fileName,unsigned.details,
                unsigned.previousHash,hash(unsigned));
        events.add(complete);
        return complete;
    }

    public static JSONObject append(JSONObject data, String action, String fileName, String details, String at) throws Exception {
        JSONArray stored=data.optJSONArray("custodyEvents");
        List<Event> events=fromJson(stored);
        Event event=appendEvent(events,action,fileName,details,at);
        if(stored==null){stored=new JSONArray();data.put("custodyEvents",stored);}
        stored.put(toJson(event));
        return stored.getJSONObject(stored.length()-1);
    }

    public static boolean verify(JSONObject data) {
        try{return verifyEvents(fromJson(data.optJSONArray("custodyEvents")));}catch(Exception e){return false;}
    }

    public static boolean verifyEvents(List<Event> events) {
        if(events==null)return false;
        String previous=ZERO_HASH;
        try {
            for(int i=0;i<events.size();i++){
                Event event=events.get(i);
                if(event==null||event.sequence!=i+1||!previous.equals(event.previousHash)||!hash(event).equals(event.eventHash))return false;
                previous=event.eventHash;
            }
            return true;
        }catch(Exception e){return false;}
    }

    private static List<Event> fromJson(JSONArray stored) throws Exception {
        List<Event> events=new ArrayList<>();
        if(stored==null)return events;
        for(int i=0;i<stored.length();i++){
            JSONObject e=stored.getJSONObject(i);
            events.add(new Event(e.getInt("sequence"),e.getString("occurredAt"),e.getString("action"),
                    e.getString("fileName"),e.getString("details"),e.getString("previousHash"),e.getString("eventHash")));
        }
        return events;
    }

    private static JSONObject toJson(Event event) throws Exception {
        return new JSONObject().put("sequence",event.sequence).put("occurredAt",event.occurredAt)
                .put("action",event.action).put("fileName",event.fileName).put("details",event.details)
                .put("previousHash",event.previousHash).put("eventHash",event.eventHash);
    }

    private static String hash(Event event) throws Exception {
        String canonical=event.sequence+"\n"+frame(event.occurredAt)+frame(event.action)+frame(event.fileName)
                +frame(event.details)+frame(event.previousHash);
        try {
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(canonical.getBytes(StandardCharsets.UTF_8));
            StringBuilder out=new StringBuilder(64);
            for(byte b:digest)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
            return out.toString();
        }catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}
    }

    private static String frame(String value){String s=value==null?"":value;return s.length()+":"+s+"\n";}
}
