package hn.webfusion.forense;

import java.util.Locale;
import java.util.List;

public final class EvidenceFiles {
    private EvidenceFiles() {}

    public static String classify(String name) {
        String ext=name!=null&&name.contains(".")?name.substring(name.lastIndexOf('.')+1).toLowerCase(Locale.ROOT):"";
        switch(ext){case "jpg":case "jpeg":return "Imagen JPEG";case "png":return "Imagen PNG";case "webp":return "Imagen WebP";case "json":return "Datos JSON";case "html":case "htm":return "Exportación HTML";case "txt":return "Texto";case "csv":return "Tabla CSV";default:return "Archivo sin clasificar";}
    }

    public static int findDuplicateIndex(List<String> hashes, String hash) {
        if(hashes==null||hash==null||hash.isEmpty())return -1;
        for(int i=0;i<hashes.size();i++)if(hash.equals(hashes.get(i)))return i;
        return -1;
    }
}
