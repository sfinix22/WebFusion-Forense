package hn.webfusion.forense;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.text.*;
import android.media.ExifInterface;
import java.io.*;
import org.json.*;
import java.util.*;
import java.time.Instant;

/** A4 report using Android's local PDF renderer; evidence bytes are never edited. */
public final class PdfReport {
    private final PdfDocument doc=new PdfDocument();
    private final TextPaint paint=new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private PdfDocument.Page page;
    private Canvas canvas;
    private int number=0,y=64;
    private PdfReport(){paint.setTextSize(11);paint.setColor(Color.rgb(25,35,45));}
    private void start(){
        page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++number).create());canvas=page.getCanvas();y=64;
        Paint header=new Paint(Paint.ANTI_ALIAS_FLAG);header.setTextSize(10);header.setColor(Color.rgb(30,90,100));
        canvas.drawText("WEBFUSION FORENSE | INFORME LOCAL",40,30,header);
        canvas.drawLine(40,40,555,40,header);
    }
    private void end(){
        Paint footer=new Paint(Paint.ANTI_ALIAS_FLAG);footer.setTextSize(9);footer.setColor(Color.DKGRAY);
        canvas.drawText("Página "+number,40,818,footer);doc.finishPage(page);page=null;
    }
    private void text(String value)throws IOException{
        // Layout each logical line; split long lines across pages at measured line boundaries.
        for(String line:value.split("\n",-1)){
            if(number>1000)throw new IOException("Informe demasiado extenso");
            if(line.isEmpty()){if(y+12>790){end();start();}y+=12;continue;}
            StaticLayout layout=StaticLayout.Builder.obtain(line,0,line.length(),paint,515).setIncludePad(false).build();
            for(int i=0;i<layout.getLineCount();i++){
                int top=layout.getLineTop(i),bottom=layout.getLineBottom(i),height=bottom-top;
                if(y+height>790){end();start();}
                canvas.save();canvas.clipRect(40,y,555,y+height);canvas.translate(40,y-top);layout.draw(canvas);canvas.restore();y+=height;
            }
        }
    }
    private void photo(File file)throws Exception{
        BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeFile(file.getPath(),options);
        int largest=Math.max(options.outWidth,options.outHeight);options.inSampleSize=1;
        while(largest/options.inSampleSize>1200)options.inSampleSize*=2;
        options.inJustDecodeBounds=false;Bitmap original=BitmapFactory.decodeFile(file.getPath(),options);
        if(original==null){text("Vista previa no disponible. El archivo figura en el informe.");return;}
        Bitmap bitmap=original;
        try{
            int orientation=1;try{orientation=new ExifInterface(file.getPath()).getAttributeInt(ExifInterface.TAG_ORIENTATION,1);}catch(IOException ignored){}
            Matrix m=new Matrix();
            switch(orientation){case 2:m.setScale(-1,1);break;case 3:m.setRotate(180);break;case 4:m.setScale(1,-1);break;case 5:m.setRotate(90);m.postScale(-1,1);break;case 6:m.setRotate(90);break;case 7:m.setRotate(-90);m.postScale(-1,1);break;case 8:m.setRotate(-90);break;}
            if(!m.isIdentity())bitmap=Bitmap.createBitmap(original,0,0,original.getWidth(),original.getHeight(),m,true);
            if(y>580){end();start();}
            float scale=Math.min(515f/bitmap.getWidth(),(770f-y)/bitmap.getHeight());
            float width=bitmap.getWidth()*scale,height=bitmap.getHeight()*scale;
            canvas.drawBitmap(bitmap,null,new RectF(40,y,40+width,y+height),new Paint(Paint.FILTER_BITMAP_FLAG));y+=(int)height+12;
        }finally{if(bitmap!=original)bitmap.recycle();original.recycle();}
    }
    private void heading(String title)throws IOException{
        paint.setTextSize(17);paint.setTypeface(Typeface.DEFAULT_BOLD);text(title);
        paint.setTextSize(11);paint.setTypeface(Typeface.DEFAULT);y+=12;
    }
    private void next(){end();start();}
    private StaticLayout layout(String value,int width){
        return StaticLayout.Builder.obtain(value,0,value.length(),paint,width).setIncludePad(false).build();
    }
    private void tableHeader()throws IOException{
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        row(new String[]{"N.º / UTC","Acción / archivo","Detalle"},false);
        paint.setTypeface(Typeface.DEFAULT);
    }
    private void row(String[] values,boolean repeatHeader)throws IOException{
        int[] widths={125,135,255};StaticLayout[] cells=new StaticLayout[3];int height=0;
        for(int i=0;i<3;i++){cells[i]=layout(values[i],widths[i]-12);height=Math.max(height,cells[i].getHeight());}
        int offset=0;
        while(offset<height){
            if(y+40>790){next();if(repeatHeader)tableHeader();}
            // Keep slices on text line boundaries, including very long event details.
            int available=790-y-12,part=Math.min(height-offset,available);
            if(part<height-offset){
                int boundary=part;
                for(StaticLayout cell:cells){
                    if(cell.getHeight()<=offset+part)continue;
                    int line=cell.getLineForVertical(offset+part);
                    boundary=Math.min(boundary,cell.getLineTop(line)-offset);
                }
                part=boundary;
            }
            if(part<=0){next();if(repeatHeader)tableHeader();continue;}
            int x=40;
            Paint border=new Paint();border.setColor(Color.LTGRAY);border.setStyle(Paint.Style.STROKE);
            for(int i=0;i<3;i++){
                canvas.drawRect(x,y,x+widths[i],y+part+12,border);
                canvas.save();canvas.clipRect(x+6,y+6,x+widths[i]-6,y+6+part);
                canvas.translate(x+6,y+6-offset);cells[i].draw(canvas);canvas.restore();x+=widths[i];
            }
            y+=part+12;offset+=part;
            if(offset<height){next();if(repeatHeader)tableHeader();}
        }
    }
    private static String action(String code){
        switch(code){case "PHOTO_NOTE_UPDATED":return "Cambio de nota";case "CASE_CREATED":return "Creación del caso";case "IMPORT":return "Importación";
        case "VERIFY":return "Verificación";case "METADATA_READ":return "Lectura de metadatos";
        case "RESTORE":return "Restauración";case "CASE_RENAMED":return "Cambio de nombre";default:return code;}
    }
    public static void write(OutputStream out,JSONObject data,File directory)throws Exception{
        PdfReport pdf=new PdfReport();
        try{
            JSONArray files=data.getJSONArray("files"),events=data.optJSONArray("custodyEvents");
            LinkedHashMap<String,List<JSONObject>> groups=new LinkedHashMap<>();int duplicates=0;
            for(int i=0;i<files.length();i++){
                JSONObject entry=files.getJSONObject(i);String hash=entry.optString("sha256");
                String key=hash.matches("[a-fA-F0-9]{64}")?hash.toLowerCase(Locale.ROOT):"entry-"+i;
                groups.computeIfAbsent(key,k->new ArrayList<>()).add(entry);
                if(entry.optBoolean("duplicate"))duplicates++;
            }
            pdf.start();pdf.heading("INFORME DE ANÁLISIS LOCAL");
            pdf.text("WebFusion 0.4.5\nGenerado UTC: "+Instant.now()+"\n");
            pdf.heading(data.optString("title","Caso sin título"));
            pdf.text("Cliente: "+data.optString("client")+"\nAlcance: "+data.optString("scope")+
                "\nReferencia de autorización: "+data.optString("authorizationReference")+
                "\nCreado UTC: "+data.optString("createdAt")+"\nID local: "+directory.getName()+"\n");
            pdf.heading("Resumen");
            pdf.text("Importaciones registradas: "+files.length()+"\nContenidos únicos por SHA-256: "+groups.size()+
                "\nRegistros marcados como duplicados: "+duplicates+"\nEventos de custodia: "+(events==null?0:events.length())+
                "\nCadena local: "+(CustodyLog.verify(data)?"coincide en esta comprobación":"NO COINCIDE; revisar")+"\n");
            pdf.heading("Alcance y limitaciones");
            pdf.text("Análisis de archivos seleccionados; no es una imagen forense completa. La autorización es declarada por el usuario. " +
                "Las fechas de importación no son fechas de los hechos. Los metadatos pueden modificarse. " +
                "El registro local no constituye firma digital, sello de tiempo externo ni certificación pericial.\n"+
                "Las verificaciones mostradas son las últimas guardadas; exportar no vuelve a verificar las copias. " +
                "Las vistas previas son reducidas. Conserva el respaldo con los bytes originales y el registro completo.");
            int index=0;
            for(List<JSONObject> group:groups.values()){
                JSONObject entry=group.get(0);pdf.next();pdf.heading("Ficha "+(++index)+" · "+entry.optString("name"));
                pdf.text("Clasificación: "+entry.optString("classification","Sin clasificar")+"\nTamaño: "+entry.optLong("bytes")+
                    " bytes\nSHA-256: "+entry.optString("sha256")+"\nImportaciones de este contenido: "+group.size()+"\n");
                for(int j=0;j<group.size();j++){
                    JSONObject copy=group.get(j),verification=copy.optJSONObject("lastVerification");
                    pdf.text("Importación "+(j+1)+": "+copy.optString("name")+" · UTC: "+copy.optString("importedAt")+
                        (copy.optBoolean("duplicate")?" · DUPLICADO":"")+"\n"+
                        "Verificación: "+(verification==null?"No realizada":verification.optString("status")+" · UTC: "+verification.optString("checkedAt")));
                    if(copy.has("userNoteUpdatedAt"))pdf.text("NOTA DEL ANALISTA · Importación "+(j+1)+"\n"+(copy.optString("userNote").isEmpty()?"Sin nota actual.":copy.optString("userNote"))+"\nActualizada UTC: "+copy.optString("userNoteUpdatedAt"));
                    if(copy.has("sourceNote"))pdf.text("Origen: "+copy.optString("sourceNote"));
                    if(verification!=null)pdf.text("SHA-256 comprobado: "+verification.optString("actualSha256")+"\nBytes comprobados: "+verification.optLong("actualBytes"));
                }
                if("image".equals(entry.optString("kind"))){
                    // Metadata belongs to each import; retain any differing stored readings.
                    Set<String> readings=new HashSet<>();
                    for(int j=0;j<group.size();j++){
                        String description=PhotoMetadata.describe(group.get(j).optJSONObject("photoMetadata"));
                        if(readings.add(description))pdf.text("\nLectura guardada · importación "+(j+1)+"\n"+description);
                    }
                    String local=entry.getString("localFile");if(!local.matches("[a-f0-9-]{36}[.]bin"))throw new IOException("Referencia inválida");
                    pdf.text("\nVista previa · Ficha "+index+" (una imagen por contenido)");pdf.photo(new File(directory,local));
                }else if(entry.has("text"))pdf.text("\nTexto legible:\n"+entry.optString("text"));
                else if(entry.has("analysisNote"))pdf.text(entry.optString("analysisNote"));
            }
            pdf.next();pdf.heading("Registro de custodia local");
            pdf.text("Fechas UTC. El respaldo conserva los hashes de cada evento y su enlace anterior.\n");
            pdf.paint.setTextSize(9);pdf.tableHeader();
            for(int i=0;events!=null&&i<events.length();i++){
                JSONObject event=events.getJSONObject(i);
                pdf.row(new String[]{event.optInt("sequence")+"\n"+event.optString("occurredAt"),
                    action(event.optString("action"))+"\n"+event.optString("fileName"),event.optString("details")},true);
            }
            pdf.end();pdf.doc.writeTo(out);
        }finally{if(pdf.page!=null)pdf.doc.finishPage(pdf.page);pdf.doc.close();}
    }
}
