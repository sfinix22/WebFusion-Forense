package hn.webfusion.forense;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Locale;

/** EXIF wall-clock ordering only; never infers an offset or substitutes import time. */
public final class PhotoTimeline {
    private static final DateTimeFormatter EXIF=DateTimeFormatter.ofPattern("uuuu:MM:dd HH:mm:ss",Locale.ROOT).withResolverStyle(ResolverStyle.STRICT);
    private static final DateTimeFormatter DISPLAY=DateTimeFormatter.ofPattern("dd/MM/uuuu HH:mm:ss",Locale.ROOT);
    private PhotoTimeline(){}
    public static LocalDateTime parse(String value){
        if(value==null||!value.matches("[0-9]{4}:[0-9]{2}:[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}"))return null;
        try{LocalDateTime date=LocalDateTime.parse(value,EXIF);return date.getYear()>0?date:null;}catch(DateTimeParseException e){return null;}
    }
    public static int compare(String first,String second){
        LocalDateTime a=parse(first),b=parse(second);
        if(a==null)return b==null?0:1;
        return b==null?-1:a.compareTo(b);
    }
    public static String display(String value){LocalDateTime date=parse(value);return date==null?"Sin fecha EXIF válida":date.format(DISPLAY);}
}
