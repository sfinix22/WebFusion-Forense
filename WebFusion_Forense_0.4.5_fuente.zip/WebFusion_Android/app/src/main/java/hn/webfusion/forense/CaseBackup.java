package hn.webfusion.forense;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.zip.*;
import org.json.*;

/** Portable case snapshot. Restores only into a new, private staging directory. */
public final class CaseBackup {
    public static final long LIMIT=1024L*1024*1024;
    private static final long JSON_LIMIT=16L*1024*1024;
    private CaseBackup(){}
    public static boolean allowed(String name){return name.equals("case.json")||name.equals("webfusion-backup.txt")||name.matches("[a-f0-9-]{36}\\.bin");}
    public static JSONObject validate(File dir)throws Exception{
        File manifest=new File(dir,"case.json");
        if(!manifest.isFile()||manifest.length()>JSON_LIMIT)throw new IOException("Ficha ausente o demasiado grande");
        JSONObject data=new JSONObject(new String(Files.readAllBytes(manifest.toPath()),StandardCharsets.UTF_8));
        if(data.getInt("version")!=1)throw new IOException("Versión de caso no compatible");
        for(String key:new String[]{"title","client","scope","authorizationReference","createdAt"})data.getString(key);
        JSONArray entries=data.getJSONArray("files");
        if(entries.length()>100)throw new IOException("Demasiados archivos");
        Set<String> expected=new HashSet<>(Arrays.asList("case.json","webfusion-backup.txt"));
        long total=manifest.length();
        for(int i=0;i<entries.length();i++){
            JSONObject e=entries.getJSONObject(i);String name=e.getString("localFile");
            if(!name.matches("[a-f0-9-]{36}\\.bin")||!expected.add(name))throw new IOException("Referencia de archivo inválida");
            File f=new File(dir,name);long size=e.getLong("bytes");
            if(size<0||!f.isFile()||f.length()!=size)throw new IOException("Archivo ausente o tamaño diferente: "+e.optString("name"));
            total+=size;if(total>LIMIT)throw new IOException("El respaldo supera 1 GB");
            try(InputStream in=new FileInputStream(f)){if(!Digests.hash(in,256L*1024*1024).equals(e.getString("sha256")))throw new IOException("SHA-256 diferente: "+e.optString("name"));}
        }
        File[] files=dir.listFiles();if(files==null)throw new IOException("Carpeta no disponible");
        for(File f:files)if(!expected.contains(f.getName())||!f.isFile())throw new IOException("Contenido inesperado");
        if(!CustodyLog.verify(data))throw new IOException("La cadena de custodia no coincide");
        return data;
    }
    public static void create(File dir,OutputStream output)throws Exception{
        try(ZipOutputStream zip=new ZipOutputStream(output)){
            JSONObject data=validate(dir);
            zip.putNextEntry(new ZipEntry("webfusion-backup.txt"));zip.write("WEBFUSION-BACKUP-1\n".getBytes(StandardCharsets.UTF_8));zip.closeEntry();
            ArrayList<String> names=new ArrayList<>();names.add("case.json");JSONArray a=data.getJSONArray("files");
            for(int i=0;i<a.length();i++)names.add(a.getJSONObject(i).getString("localFile"));
            for(String name:names){zip.putNextEntry(new ZipEntry(name));try(InputStream in=new FileInputStream(new File(dir,name))){Digests.copyAndHash(in,zip,LIMIT);}zip.closeEntry();}
        }
    }
    public static void extract(InputStream input,File stage,long budget)throws Exception{
        Set<String> seen=new HashSet<>();long remaining=Math.min(budget,LIMIT);
        try(ZipInputStream zip=new ZipInputStream(input)){
            ZipEntry entry;
            while((entry=zip.getNextEntry())!=null){
                String name=entry.getName();
                if(entry.isDirectory()||!allowed(name)||!seen.add(name)||seen.size()>102)throw new IOException("Estructura de respaldo inválida");
                File file=new File(stage,name);
                long limit=name.endsWith(".bin")?256L*1024*1024:JSON_LIMIT;
                try(OutputStream out=new FileOutputStream(file)){Digests.copyAndHash(zip,out,Math.min(remaining,limit));}
                remaining-=file.length();zip.closeEntry();
            }
        }
        File marker=new File(stage,"webfusion-backup.txt");
        if(!marker.isFile()||!new String(Files.readAllBytes(marker.toPath()),StandardCharsets.UTF_8).equals("WEBFUSION-BACKUP-1\n"))throw new IOException("No es un respaldo de WebFusion");
    }
}
