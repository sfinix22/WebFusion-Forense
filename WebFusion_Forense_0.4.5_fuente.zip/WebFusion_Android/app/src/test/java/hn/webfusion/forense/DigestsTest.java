package hn.webfusion.forense;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
public class DigestsTest {
    @Test public void verificationHashAndChanges() throws Exception {
        String original=Digests.hash(new ByteArrayInputStream("abc".getBytes(StandardCharsets.UTF_8)),3);
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",original);
        assertNotEquals(original,Digests.hash(new ByteArrayInputStream("abd".getBytes(StandardCharsets.UTF_8)),3));
    }
    @Test public void knownVectorAndExactCopy() throws Exception {
        byte[] source="abc".getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream copy=new ByteArrayOutputStream();
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            Digests.copyAndHash(new ByteArrayInputStream(source),copy,3));
        assertArrayEquals(source,copy.toByteArray());
    }
    @Test(expected=IOException.class) public void enforcesLimit() throws Exception {
        Digests.copyAndHash(new ByteArrayInputStream(new byte[4]),new ByteArrayOutputStream(),3);
    }
    @Test public void emptyInput() throws Exception {
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            Digests.copyAndHash(new ByteArrayInputStream(new byte[0]),new ByteArrayOutputStream(),0));
    }
}
