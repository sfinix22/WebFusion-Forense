package hn.webfusion.forense;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Locale;
public class MapLocationTest {
 @Test public void rejectsMissingAndOutOfRange(){assertFalse(MapLocation.valid(Double.NaN,0));assertFalse(MapLocation.valid(0,Double.POSITIVE_INFINITY));assertFalse(MapLocation.valid(91,0));assertFalse(MapLocation.valid(0,-181));assertTrue(MapLocation.valid(0,0));}
 @Test public void preservesWestSignAndDecimalPoint(){Locale old=Locale.getDefault();try{Locale.setDefault(Locale.GERMANY);assertEquals("geo:0,0?q=14.7578107,-87.6082554",MapLocation.geo(14.7578107,-87.6082554));}finally{Locale.setDefault(old);}}
}
