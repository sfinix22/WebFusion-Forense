package hn.webfusion.forense;

import org.junit.Test;
import java.util.ArrayList;
import static org.junit.Assert.*;

public class CustodyLogTest {
    @Test public void verifiesLinkedEventsAndDetectsEdits() throws Exception {
        ArrayList<CustodyLog.Event> events=new ArrayList<>();
        CustodyLog.Event first=CustodyLog.appendEvent(events,"IMPORT","foto.jpg","sha256=abc","2026-09-23T00:00:00Z");
        CustodyLog.appendEvent(events,"VERIFY","foto.jpg","status=coincide","2026-09-23T00:01:00Z");
        assertTrue(CustodyLog.verifyEvents(events));
        events.set(0,new CustodyLog.Event(first.sequence,first.occurredAt,first.action,first.fileName,
                "sha256=changed",first.previousHash,first.eventHash));
        assertFalse(CustodyLog.verifyEvents(events));
    }

    @Test public void emptyLegacyCaseIsValid() {
        assertTrue(CustodyLog.verifyEvents(new ArrayList<>()));
    }

    @Test public void rejectsBrokenPreviousLink() throws Exception {
        ArrayList<CustodyLog.Event> events=new ArrayList<>();
        CustodyLog.appendEvent(events,"IMPORT","foto.jpg","sha256=abc","2026-09-23T00:00:00Z");
        CustodyLog.Event first=events.get(0);
        events.add(new CustodyLog.Event(2,"2026-09-23T00:01:00Z","VERIFY","foto.jpg","ok","broken","fake"));
        assertFalse(CustodyLog.verifyEvents(events));
    }
}
