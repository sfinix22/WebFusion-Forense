package hn.webfusion.forense;
import org.junit.Test;
import static org.junit.Assert.*;
public class PhotoFieldsTest {
 @Test public void northAndWest(){
  assertEquals(15.5,PhotoFields.coordinate("15/1,30/1,0/1","N",true),0.000001);
  assertEquals(-86.25,PhotoFields.coordinate("86/1,15/1,0/1","W",false),0.000001);
 }
 @Test public void southAndEast(){
  assertEquals(-12.5,PhotoFields.coordinate("12,30,0","S",true),0.000001);
  assertEquals(45.5,PhotoFields.coordinate("45,30,0","E",false),0.000001);
 }
 @Test public void zeroIsValid(){assertEquals(0.0,PhotoFields.coordinate("0,0,0","N",true),0.0);}
 @Test public void missingDoesNotBecomeZero(){assertNull(PhotoFields.coordinate(null,"N",true));assertNull(PhotoFields.coordinate("0,0,0",null,true));}
 @Test public void malformedAndBounds(){
  for(String value:new String[]{"91,0,0","90,0,1","15,60,0","15,0,60","NaN,0,0","1/0,0,0","-1,0,0","1,2","bad"})assertNull(value,PhotoFields.coordinate(value,"N",true));
  assertNull(PhotoFields.coordinate("1,0,0","W",true));
  assertNull(PhotoFields.coordinate("181,0,0","E",false));
 }
}
