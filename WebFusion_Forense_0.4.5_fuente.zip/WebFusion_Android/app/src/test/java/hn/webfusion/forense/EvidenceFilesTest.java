package hn.webfusion.forense;

import org.junit.Test;
import java.util.Arrays;
import static org.junit.Assert.*;

public class EvidenceFilesTest {
    @Test public void classifiesSupportedExtensionsCaseInsensitively() {
        assertEquals("Imagen JPEG", EvidenceFiles.classify("PHOTO.JpG"));
        assertEquals("Datos JSON", EvidenceFiles.classify("messages.json"));
        assertEquals("Tabla CSV", EvidenceFiles.classify("table.csv"));
        assertEquals("Archivo sin clasificar", EvidenceFiles.classify("archive.zip"));
    }

    @Test public void matchesDuplicatesByHashOnly() {
        assertEquals(0, EvidenceFiles.findDuplicateIndex(Arrays.asList("abc", "def"), "abc"));
        assertEquals(1, EvidenceFiles.findDuplicateIndex(Arrays.asList("abc", "def"), "def"));
        assertEquals(-1, EvidenceFiles.findDuplicateIndex(Arrays.asList("abc", "def"), "different"));
        assertEquals(-1, EvidenceFiles.findDuplicateIndex(Arrays.asList("abc"), ""));
    }
}
