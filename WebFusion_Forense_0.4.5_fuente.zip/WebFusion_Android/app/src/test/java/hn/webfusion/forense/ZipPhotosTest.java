package hn.webfusion.forense;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.*;
import java.nio.file.*;
import java.util.zip.*;
public class ZipPhotosTest {
 private File archive(File dir,String name,byte[] bytes)throws Exception{
  File f=new File(dir,"test.zip");try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(f))){z.putNextEntry(new ZipEntry(name));z.write(bytes);z.closeEntry();}return f;
 }
 @Test public void preservesBytesAndMemberName()throws Exception{
  File dir=Files.createTempDirectory("zip-test").toFile();try{
   byte[] bytes={0,(byte)255,1,2,3};File f=archive(dir,"DCIM/test.jpg",bytes);
   ZipPhotos.Photo p=ZipPhotos.extract(f,dir,100,1).get(0);
   assertEquals("DCIM/test.jpg",p.member);assertArrayEquals(bytes,Files.readAllBytes(p.file.toPath()));
  }finally{ZipPhotos.cleanup(dir);}
 }
 @Test public void rejectsTraversal()throws Exception{reject("../outside.jpg",10,1);}
 @Test public void enforcesExpandedSize()throws Exception{reject("photo.jpg",2,1);}
 @Test public void enforcesCount()throws Exception{reject("photo.jpg",10,0);}
 private void reject(String name,long limit,int count)throws Exception{
  File dir=Files.createTempDirectory("zip-test").toFile();try{
   File f=archive(dir,name,new byte[]{1,2,3});
   try{ZipPhotos.extract(f,dir,limit,count);fail("Expected bounded import rejection");}catch(IOException expected){}
  }finally{ZipPhotos.cleanup(dir);}
 }
}
