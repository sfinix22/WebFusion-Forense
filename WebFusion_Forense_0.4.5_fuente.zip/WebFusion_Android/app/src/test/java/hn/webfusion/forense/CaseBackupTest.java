package hn.webfusion.forense;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.*;
import java.nio.file.*;
import java.util.zip.*;
public class CaseBackupTest {
    private byte[] zip(String name,byte[] content)throws Exception{
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        try(ZipOutputStream z=new ZipOutputStream(b)){
            z.putNextEntry(new ZipEntry("webfusion-backup.txt"));z.write("WEBFUSION-BACKUP-1\n".getBytes("UTF-8"));z.closeEntry();
            z.putNextEntry(new ZipEntry(name));z.write(content);z.closeEntry();
        }return b.toByteArray();
    }
    @Test public void preservesEvidenceBytes()throws Exception{
        File dir=Files.createTempDirectory("backup-test").toFile();String name="12345678-1234-1234-1234-123456789012.bin";byte[] b={1,0,3,4,-1};
        try{CaseBackup.extract(new ByteArrayInputStream(zip(name,b)),dir,1000);assertArrayEquals(b,Files.readAllBytes(new File(dir,name).toPath()));}finally{ZipPhotos.cleanup(dir);}
    }
    @Test public void rejectsTraversal()throws Exception{reject("../outside",new byte[1],1000);}
    @Test public void rejectsExcessExpansion()throws Exception{reject("case.json",new byte[1000],100);}
    @Test public void rejectsUnknownMember()throws Exception{reject("other.txt",new byte[1],1000);}
    @Test public void rejectsMissingMarker()throws Exception{
        File dir=Files.createTempDirectory("backup-empty").toFile();
        try{try{CaseBackup.extract(new ByteArrayInputStream(new byte[0]),dir,100);fail("Missing marker accepted");}catch(IOException expected){}}finally{ZipPhotos.cleanup(dir);}
    }
    private void reject(String name,byte[] b,long budget)throws Exception{
        File dir=Files.createTempDirectory("backup-bad").toFile();
        try{try{CaseBackup.extract(new ByteArrayInputStream(zip(name,b)),dir,budget);fail("Accepted invalid archive");}catch(IOException expected){}}finally{ZipPhotos.cleanup(dir);}
    }
}
