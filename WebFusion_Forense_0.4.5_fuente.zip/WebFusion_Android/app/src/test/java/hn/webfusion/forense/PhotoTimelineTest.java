package hn.webfusion.forense;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;
public class PhotoTimelineTest {
 @Test public void sortsAcrossYearsAndPutsMissingLast(){List<String> dates=new ArrayList<>(Arrays.asList(null,"2026:01:01 00:00:00","2025:12:31 23:59:59","bad"));dates.sort(PhotoTimeline::compare);assertEquals("2025:12:31 23:59:59",dates.get(0));assertEquals("2026:01:01 00:00:00",dates.get(1));assertNull(dates.get(2));assertEquals("bad",dates.get(3));}
 @Test public void rejectsImpossibleDatesAndTimes(){for(String s:Arrays.asList("2026:02:29 09:00:00","2026:04:31 09:00:00","2026:01:01 24:00:00","0000:00:00 00:00:00","2026:01:01 10:00:00Z","2026:1:1 10:00:00"))assertNull(s,PhotoTimeline.parse(s));assertNotNull(PhotoTimeline.parse("2024:02:29 09:00:00"));}
 @Test public void preservesEqualTimestamps(){assertEquals(0,PhotoTimeline.compare("2026:09:24 09:25:30","2026:09:24 09:25:30"));}
 @Test public void doesNotConvertTimezone(){TimeZone old=TimeZone.getDefault();try{TimeZone.setDefault(TimeZone.getTimeZone("Pacific/Auckland"));assertEquals("24/09/2026 09:25:30",PhotoTimeline.display("2026:09:24 09:25:30"));}finally{TimeZone.setDefault(old);}}
}
