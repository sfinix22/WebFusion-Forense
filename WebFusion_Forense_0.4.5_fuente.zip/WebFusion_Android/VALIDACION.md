# Validación 0.3.6

## Cambios

Importación limitada de fotos desde ZIP, preservación de bytes y CRC, registro de origen, y corrección del tratamiento de URI directas de MediaStore. Código de versión 9; paquete de prueba hn.webfusion.forense.test. Misma clave de firma que 0.3.5.

## Comprobaciones realizadas

- Compilación Java 17 con SDK Platform 35, empaquetado Build Tools 34.0.0/D8 y firma v2/v3 verificada.
- 18 pruebas JUnit aprobadas. Incluyen preservación de bytes al descomprimir, límite de tamaño, límite de fotos y rechazo de rutas con recorrido hacia directorios superiores.
- Se ejecutó la clase ZipPhotos del APK sobre el ZIP proporcionado para diagnóstico. El SHA-256 del JPG extraído coincide con el miembro del ZIP. Lectura independiente con Pillow confirmó que conserva latitud y longitud EXIF.
- La foto privada y sus coordenadas no se incluyen en el código fuente ni en el APK.

## Pendiente

No se dispone de ejecución en dispositivo/emulador Android para reproducir la entrega de URI de Samsung ni ejecutar ExifInterface en el teléfono. Falta comprobar la importación y visualización GPS de extremo a extremo con 0.3.6. La importación ZIP es una vía alternativa comprobada para conservar los bytes; no demuestra que todos los proveedores de fotos entreguen originales con GPS.


## Corrección 0.3.8
La entrega 0.3.7 conservaba MainActivity 0.3.6. Se integraron los botones y flujos de respaldo/restauración. Se verifica también el DEX del APK final: versión 0.3.8, ambos botones y métodos presentes, ausencia de 0.3.6. Sigue pendiente la prueba completa en teléfono.


## 0.4.0: organización de casos
Renombrar caso valida nombre no vacío, máximo 120 caracteres, y registra CASE_RENAMED. La escritura atómica precede al cambio en memoria. Casos restaurados se reconocen por su evento RESTORE, incluidos los de 0.3.8; el listado y encabezado muestran RESTAURADO e ID local corto. El informe incluye ID local completo y fecha de última restauración. Compilación, 23 pruebas existentes y comprobación DEX de controles nuevos. Pendiente probar la interfaz en teléfono. Mapas y PDF no incluidos en esta entrega.


## 0.4.1: mapa de la foto
La ficha de cada foto muestra Abrir ubicación en el mapa si tiene latitud y longitud finitas dentro de rango. Abre una aplicación externa con las coordenadas EXIF; si falta, abre Google Maps en navegador. No consulta ubicación actual ni envía la foto. El proveedor de mapas recibe las coordenadas al pulsar el botón. Pruebas de rango, valores ausentes y formato independiente de idioma: 25 pruebas totales. Firma y controles del APK final verificados. Apertura real de mapas pendiente en teléfono.


## 0.4.2: exportación PDF
Botón Exportar informe PDF. Generación local con Android PdfDocument, texto del informe TXT completo, páginas A4 y anexo por cada entrada de imagen. Miniaturas limitadas a 1200 píxeles con orientación EXIF aplicada; no cambia la evidencia. Incluye última verificación guardada, no ejecuta una nueva. No agrega eventos al exportar. Datos y coordenadas permanecen locales al generar.
Compilación, firma, 25 pruebas existentes y presencia de botón/método en DEX comprobados. No se ha ejecutado el renderizador Android ni revisado visualmente un PDF real: pendiente exportar en Samsung, abrir y revisar acentos, páginas largas y fotos.


## 0.4.3: PDF organizado
Portada con resumen, fichas agrupadas por SHA-256 y tabla de custodia paginada. Una vista previa por contenido; se conservan todas las importaciones, verificaciones y lecturas de metadatos distintas. El respaldo conserva los hashes completos de los eventos. TXT y evidencias no se modifican.
Validación: compilación Android SDK 35, 25 pruebas JVM existentes aprobadas, firma APK y versión DEX comprobadas. Las pruebas existentes no ejecutan el renderizador PDF; revisión visual del PDF 0.4.3 pendiente en dispositivo.
APK de prueba: hn.webfusion.forense.test, versionCode 15, versión 0.4.3-test; instalar como actualización sobre la prueba anterior.


## 0.4.4: línea de tiempo de fotos
Nuevo botón Línea de tiempo de fotos. Orden ascendente estricto por DateTimeOriginal, sin conversión de zona horaria ni sustitución por fecha de importación. Fechas ausentes o inválidas al final; empates conservan orden de importación. Incluye duplicados identificados, GPS disponible, acceso a detalles y mapa. Consulta de solo lectura; no cambia el caso ni las evidencias.
Validación: 29 pruebas JVM aprobadas, incluyendo 4 nuevas de cronología (orden entre años, calendario inválido, empates, independencia de zona horaria). Compilación, firma y presencia de función/botón/versión en DEX verificadas. Interfaz pendiente de prueba en Samsung; sin emulador disponible. Paquete hn.webfusion.forense.test, versionCode 16, 0.4.4-test.


## 0.4.5: notas de análisis
Editar nota de análisis desde cada foto, máximo 2000 caracteres. La nota corresponde a una importación identificada por localFile, no se propaga a duplicados. Guardado atómico de nota, fecha UTC y evento PHOTO_NOTE_UPDATED con texto anterior/nuevo e identificador. Guardar sin cambios no añade evento; vaciar la nota conserva el historial. Se incluyen notas actuales en TXT y PDF, junto a la importación correspondiente. Respaldos conservan el case.json completo. No se escriben bytes de imágenes.
Compilación, firma, versión y funciones DEX comprobadas; 29 pruebas existentes aprobadas. Estas pruebas no cubren la interfaz de notas ni el renderizado PDF: validación en dispositivo pendiente. Paquete de prueba hn.webfusion.forense.test, versionCode 17, 0.4.5-test.
