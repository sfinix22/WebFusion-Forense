# WebFusion Forense Android 0.3.6

Proyecto Android local para inventariar y revisar archivos seleccionados por el usuario. Esta entrega contiene el código fuente; la APK de prueba 0.3.6 se entrega por separado.

## Novedades de 0.3
- SHA-256 automático al importar y herramienta para verificar que las copias siguen iguales.
- Clasificación básica por extensión y aviso de duplicados cuando el SHA-256 coincide exactamente.
- Lectura EXIF de JPG/JPEG: fabricante, modelo, fecha original, fecha de digitalización y fecha de modificación, si existen.
- Conversión de coordenadas EXIF GPS a grados decimales cuando los datos y sus referencias son válidos. No usa la ubicación del teléfono ni pide permisos de ubicación.
- Registro local de creación de caso, importaciones, lecturas de metadatos y verificaciones. Cada evento enlaza el hash del anterior; se verifica al exportar y antes de añadir eventos nuevos.
- Informe TXT mejorado con resumen, clasificación, hashes, coincidencias duplicadas, metadatos y registro de eventos.
- En 0.3.2 la pantalla muestra la versión en grande y accesos «Ver duplicados» y «Ver custodia». El contador del caso muestra archivos, duplicados y eventos.
- En 0.3.3, «Leer metadatos de fotos» abre un resumen después de procesarlas. La vista individual muestra los datos antes de la imagen. Cuando la copia no tiene EXIF legible, lo indica expresamente.

- En 0.3.4, el informe TXT comienza con una marca UTF-8 para facilitar que los visores detecten bien las tildes y la ñ.

- En 0.3.5, la importación solicita el permiso de ubicación de fotos y pide bytes originales para fotos compatibles de MediaStore; si falta el permiso, Android puede entregar una copia con GPS oculto. La app no consulta la ubicación actual. Reimporta la foto tras conceder el permiso: una copia anterior no recupera las etiquetas que Android ocultó.

Las fechas EXIF se muestran tal como están guardadas, sin asumir zona horaria ni convertirlas a UTC. La ausencia de GPS se informa para la copia importada; algunos proveedores pueden entregar una copia sin metadatos. Una coincidencia de hash confirma igualdad de bytes, no que dos archivos tengan igual significado. El registro encadenado puede mostrar modificaciones de eventos, pero está guardado en el mismo almacenamiento local, no lleva firma ni sello de tiempo externo y no constituye certificación pericial.

La lectura EXIF se limita a JPG/JPEG. PNG y WebP se inventarían y previsualizan, pero sus metadatos no se interpretan. La clasificación usa la extensión del nombre y no valida el contenido del archivo.

## Límites y privacidad
Los casos quedan en almacenamiento privado de la app y se eliminan al desinstalarla. No hay cifrado adicional propio; el informe puede contener datos privados. La autorización es una referencia declarada, no verificada por la app. No desbloquea teléfonos, no descifra archivos, no recupera eliminados, no hace extracción ADB/MTP ; los ZIP solo permiten extraer fotos compatibles. USB solo enumera dispositivos conectados. No se afirma certificación ni validez pericial.

## Compilar y probar
Requisitos: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK Platform 35 y Build Tools 34.0.0. Con `ANDROID_HOME` configurado, ejecuta:

    bash gradlew testDebugUnitTest assembleDebug

La APK Gradle se genera en `app/build/outputs/apk/debug/app-debug.apk`. La APK de prueba entregada se compiló con Android SDK Build Tools y usa el identificador `hn.webfusion.forense.test`. En el teléfono debe aparecer como **WebFusion 0.3.6 Prueba**. La firma coincide con la APK de prueba 0.3.5 y `versionCode` subió a 9, por lo que se puede instalar sobre esa prueba conservando sus casos. La aplicación normal tiene almacenamiento separado. Para actualizar la app normal hace falta compilar y firmar con la misma clave que la APK que ya tiene instalada; no la desinstales para resolver un rechazo de firma, pues eso elimina sus casos.

Antes de distribuir comercialmente, configura una firma de producción propia y revisa las condiciones de Android, Gradle, JDK y JUnit. No se incluye una clave de firma.

## Corrección 0.3.6: GPS e importación ZIP
- `Importar archivos` acepta ZIP con JPG/JPEG/PNG/WebP. Solo JPEG interpreta EXIF en esta versión. Se conservan los bytes de cada miembro, se comprueba CRC, se calcula SHA-256 y se registra el nombre/hash del ZIP de origen y la ruta del miembro.
- Límites: 100 archivos por caso, 1000 entradas por ZIP, 256 MiB de fotos descomprimidas como máximo por ZIP y límite adicional por espacio libre. Rutas que salen del archivo se rechazan. No se extraen ZIP anidados.
- Las URI directas de MediaStore se tratan directamente como medios; las URI de documentos se convierten cuando el proveedor lo admite. La importación de ZIP permite conservar el contenido comprobado independientemente de la ocultación de ubicación al compartir fotos.
- Para comprobar GPS, selecciona el ZIP original en Importar archivos. Puedes continuar sin el permiso de ubicación de fotos si importas desde ZIP. Abre el JPG nuevo en el caso.
- La ausencia de GPS en una copia anterior no se repara al releerla. Importa de nuevo desde una fuente que conserve los datos.


## 0.4.0
Abre un caso y pulsa Renombrar caso. El cambio queda en custodia. Los casos restaurados llevan la etiqueta RESTAURADO y todos muestran un identificador local corto para distinguir nombres repetidos.


## 0.4.1: mapa de la foto
La ficha de cada foto muestra Abrir ubicación en el mapa si tiene latitud y longitud finitas dentro de rango. Abre una aplicación externa con las coordenadas EXIF; si falta, abre Google Maps en navegador. No consulta ubicación actual ni envía la foto. El proveedor de mapas recibe las coordenadas al pulsar el botón. Pruebas de rango, valores ausentes y formato independiente de idioma: 25 pruebas totales. Firma y controles del APK final verificados. Apertura real de mapas pendiente en teléfono.


## 0.4.2: exportación PDF
Botón Exportar informe PDF. Generación local con Android PdfDocument, texto del informe TXT completo, páginas A4 y anexo por cada entrada de imagen. Miniaturas limitadas a 1200 píxeles con orientación EXIF aplicada; no cambia la evidencia. Incluye última verificación guardada, no ejecuta una nueva. No agrega eventos al exportar. Datos y coordenadas permanecen locales al generar.
Compilación, firma, 25 pruebas existentes y presencia de botón/método en DEX comprobados. No se ha ejecutado el renderizador Android ni revisado visualmente un PDF real: pendiente exportar en Samsung, abrir y revisar acentos, páginas largas y fotos.


## 0.4.3: PDF organizado
Portada con resumen, fichas agrupadas por SHA-256 y tabla de custodia paginada. Una vista previa por contenido; se conservan todas las importaciones, verificaciones y lecturas de metadatos distintas. El respaldo conserva los hashes completos de los eventos. TXT y evidencias no se modifican.
Validación: compilación Android SDK 35, 25 pruebas JVM existentes aprobadas, firma APK y versión DEX comprobadas. Las pruebas existentes no ejecutan el renderizador PDF; revisión visual del PDF 0.4.3 pendiente en dispositivo.
APK de prueba: hn.webfusion.forense.test, versionCode 15, versión 0.4.3-test; instalar como actualización sobre la prueba anterior.


## 0.4.4: línea de tiempo de fotos
Nuevo botón Línea de tiempo de fotos. Orden ascendente estricto por DateTimeOriginal, sin conversión de zona horaria ni sustitución por fecha de importación. Fechas ausentes o inválidas al final; empates conservan orden de importación. Incluye duplicados identificados, GPS disponible, acceso a detalles y mapa. Consulta de solo lectura; no cambia el caso ni las evidencias.
Validación: 29 pruebas JVM aprobadas, incluyendo 4 nuevas de cronología (orden entre años, calendario inválido, empates, independencia de zona horaria). Compilación, firma y presencia de función/botón/versión en DEX verificadas. Interfaz pendiente de prueba en Samsung; sin emulador disponible. Paquete hn.webfusion.forense.test, versionCode 16, 0.4.4-test.


## 0.4.5: notas de análisis
Editar nota de análisis desde cada foto, máximo 2000 caracteres. La nota corresponde a una importación identificada por localFile, no se propaga a duplicados. Guardado atómico de nota, fecha UTC y evento PHOTO_NOTE_UPDATED con texto anterior/nuevo e identificador. Guardar sin cambios no añade evento; vaciar la nota conserva el historial. Se incluyen notas actuales en TXT y PDF, junto a la importación correspondiente. Respaldos conservan el case.json completo. No se escriben bytes de imágenes.
Compilación, firma, versión y funciones DEX comprobadas; 29 pruebas existentes aprobadas. Estas pruebas no cubren la interfaz de notas ni el renderizado PDF: validación en dispositivo pendiente. Paquete de prueba hn.webfusion.forense.test, versionCode 17, 0.4.5-test.
